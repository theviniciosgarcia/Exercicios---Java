/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.avaliacao.continuada2;

import java.util.Scanner;

/**
 *
 * @author vgfagundes
 */
public class TesteValidacaoNumerica {

    public static void main(String[] args) {
        ValidacaoNumerica vn = new ValidacaoNumerica();

        Scanner leitor = new Scanner(System.in);

        Integer numeroDigitado;
        Integer numeroRestoDivisao = 0;

        do {
            System.out.println("Digite um número inteiro: ");
            numeroDigitado = leitor.nextInt();

            vn.verificaPrimo(numeroDigitado, numeroRestoDivisao);

        } while (numeroDigitado >= 0);
        System.out.println("Até Logo");
    }
}
