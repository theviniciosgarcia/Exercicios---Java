/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.avaliacao.continuada2;

import java.util.Scanner;

/**
 *
 * @author vgfagundes
 */
public class TesteDescontoProgressivo {
    public static void main(String[] args) {
        DescontoProgressivo dp = new DescontoProgressivo();
        
        Scanner leitor = new Scanner(System.in);
        
        Double valorUnitario;
        Integer qtdProduto;
        
        System.out.println("Bem vindo ao sistema de desconto progressivo!\n"
                         + "Digite o valor únitario do produto:");
        valorUnitario = leitor.nextDouble();
        
        System.out.println("Digite a quantidade:");
        qtdProduto = leitor.nextInt();
       
        Double resultadoDesconto = dp.calcularDesconto(valorUnitario, qtdProduto);
        
        dp.exibirNotaFiscal(valorUnitario, qtdProduto, resultadoDesconto);
        
    }
}
