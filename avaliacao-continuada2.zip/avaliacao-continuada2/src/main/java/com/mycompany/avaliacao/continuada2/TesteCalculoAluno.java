/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.avaliacao.continuada2;

import java.util.Scanner;

/**
 *
 * @author vgfagundes
 */
public class TesteCalculoAluno {
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        
        Double primeiraNota;
        Double segundaNota;
        
        CalculoAluno calc = new CalculoAluno();
        
        System.out.println("Digite sua primeira nota!");
        primeiraNota = leitor.nextDouble();
        
        System.out.println("Digite sua segunda nota!");
        segundaNota = leitor.nextDouble();
        
        Double resultadoMedia = calc.calcularMedia(primeiraNota, segundaNota);
        System.out.println(String.format("Sua Média é %.1f", resultadoMedia));
    }
}
