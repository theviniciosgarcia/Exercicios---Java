/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.avaliacao.continuada2;

/**
 *
 * @author vgfagundes
 */
public class ValidacaoNumerica {

    void verificaPrimo(Integer numeroDigitado, Integer numeroRestoDivisao) {
        
            for (int i = 1; i <= numeroDigitado; i++) {
                if (numeroDigitado % i == 0) {
                    numeroRestoDivisao++;
                }
            }
            
            if (numeroRestoDivisao == 2){
                System.out.println(String.format("O número: %d é número Primo!", numeroDigitado));
            } else {
                System.out.println(String.format("O número: %d não é número Primo!", numeroDigitado));
            }
    }
}
