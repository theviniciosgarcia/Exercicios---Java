/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.avaliacao.continuada2;

import java.util.Scanner;

/**
 *
 * @author vgfagundes
 */
public class TesteIdade {
    public static void main(String[] args) {
        Idade idd = new Idade();
        Scanner leitor = new Scanner(System.in);
        
        Integer solicitarIdade;
        
        System.out.println("Qual é a sua Idade?");
        solicitarIdade = leitor.nextInt();
        
        idd.classificaIdade(solicitarIdade);
    }
}
