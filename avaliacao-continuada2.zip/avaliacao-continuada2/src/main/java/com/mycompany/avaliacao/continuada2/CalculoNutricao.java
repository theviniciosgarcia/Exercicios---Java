/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.avaliacao.continuada2;

/**
 *
 * @author vgfagundes
 */
public class CalculoNutricao {
    Double calculaIMC (Double peso, Double altura) {
         Double imc = peso / (altura * altura);
         if (peso == 0 || altura == 0) {
             System.out.println("Opção invalida!");
             return imc;
         } else {
         System.out.println(String.format("Seu indice de massa corporal é: %.2f", imc));
         return imc;
    }     
  }             
}
