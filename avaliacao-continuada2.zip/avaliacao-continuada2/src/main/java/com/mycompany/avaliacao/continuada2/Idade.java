/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.avaliacao.continuada2;

/**
 *
 * @author vgfagundes
 */
public class Idade {
        void classificaIdade(Integer idadeUsuario) {
            if(idadeUsuario < 2) {
                System.out.println("Bebê");
            } else if (idadeUsuario < 11) {
                System.out.println("Criança");
            } else if (idadeUsuario < 19) {
                System.out.println("Adolencente");
            } else if (idadeUsuario < 30) {
                System.out.println("Jovem");
            } else if (idadeUsuario < 60) {
                System.out.println("Adulto");
            } else {
                System.out.println("Idoso");
            }
    }
}        
