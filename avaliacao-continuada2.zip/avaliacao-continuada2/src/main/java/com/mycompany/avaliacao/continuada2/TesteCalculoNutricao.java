/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.avaliacao.continuada2;

import java.util.Scanner;

/**
 *
 * @author vgfagundes
 */
public class TesteCalculoNutricao {
    public static void main(String[] args) {
    CalculoNutricao calc = new CalculoNutricao();
    Scanner leitor = new Scanner(System.in);
    
    Double peso;
    Double altura;
    
    do {
        System.out.println("Digite sua peso: ");
        peso = leitor.nextDouble();
        
        System.out.println("Digite sua altura: ");
        altura = leitor.nextDouble();
        
        calc.calculaIMC(peso, altura);
        
    } while (peso != 0 || altura != 0);
        
    } 
}
