/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.avaliacao.continuada2;

/**
 *
 * @author vgfagundes
 */
public class DescontoProgressivo {
    Double calcularDesconto (Double valorProduto, Integer valorQuantidade) {
        if (valorQuantidade == 1) {
            Double valorDesconto = valorProduto * 0.1;
            Double valorFinal = valorProduto - valorDesconto;
            return valorFinal;
    } else if (valorQuantidade == 2) {
            Double valorCheio = (valorProduto * valorQuantidade);
            Double valorDesconto = valorCheio * 0.2;
            Double valorFinal =  valorCheio - valorDesconto;
           return valorFinal;
    } else {
            Double valorCheio = (valorProduto * valorQuantidade);
            Double valorDesconto = valorCheio * 0.2;
            Double valorFinal = valorCheio - valorDesconto;
            return valorFinal;
    }
  }
    
    void exibirNotaFiscal (Double valorProduto, Integer valorQuantidade, Double valorFinal) {
        System.out.println(String.format("----------------------\n"
                         + "Valor do produto: R$ %.1f\n"
                         + "Quantidade: %d\n"
                         + "----------------------------\n"
                         + "Valor com desconto: %.1f", valorProduto, valorQuantidade, valorFinal));
    }
}

