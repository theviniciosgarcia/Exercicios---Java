/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.terceira.lista.nivelameto;

/**
 *
 * @author vgfagundes
 */
public class ClasseSocial {
    
    Double qtdSalariosMinimos (Double salarioTotal) {
        Double dividir = salarioTotal / 1045;
        return dividir;
    }
    
    String verificarClasseSocial (Double qtdSalarios) {
        if(qtdSalarios < 2) {
        return "E";
       } else if (qtdSalarios < 4) {
          return "D";
       } else if (qtdSalarios < 10) {
           return "C";
       } else if (qtdSalarios < 20) {
           return "B";
       } else {
           return "A";
       }
    }
}
