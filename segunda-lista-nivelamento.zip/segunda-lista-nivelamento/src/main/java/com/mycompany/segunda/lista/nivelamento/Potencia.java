/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.segunda.lista.nivelamento;

import java.util.Scanner;

/**
 *
 * @author vgfagundes
 */
public class Potencia {
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        
        System.out.println("Digite um numero Base:");
        Integer numeroBase = leitor.nextInt();
        
        System.out.println("Digite um número expoente");
        Integer numeroExpoente = leitor.nextInt();
        
        Integer resultado = 1;
          
        for (int i = 0; i < numeroExpoente; i++) {
            resultado *= numeroBase;
        }
        System.out.println(resultado);
    }
}