/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.segunda.lista.nivelamento;

import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

/**
 *
 * @author vgfagundes
 */
public class Sorteio {

    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);

        System.out.println("Solicite um número de 0 a 100");
        Integer numeroEscolhido = leitor.nextInt();

        Integer posicao = 0;
        Integer numerosPares = 0;
        Integer numerosImpares = 0;
        Integer numeroSorteado = ThreadLocalRandom.current().nextInt(1, 101);

        Boolean verificarPosicao = true;

        int i = 0;
        while (numeroEscolhido != numeroSorteado) {
            numeroSorteado = ThreadLocalRandom.current().nextInt(1, 201);
            System.out.println(numeroSorteado);
            i++;
            if (numeroEscolhido == numeroSorteado) {
                if (verificarPosicao) {
                    posicao = i;
                    verificarPosicao = false;
                }
            }
                
                if (numeroSorteado % 2 == 0) {
                    numerosPares++;
                }

                if (numeroSorteado % 2 == 1) {
                    numerosImpares++;
                }
        }
        System.out.println(String.format("A posição é: %d, a Quantidade de numeros pares é %d, a Quantidade de numeros impares é: %d", posicao, numerosPares, numerosImpares));
    }
}
