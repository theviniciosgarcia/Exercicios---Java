/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.segunda.lista.nivelamento;

import java.util.Scanner;

/**
 *
 * @author vgfagundes
 */
public class Acumulador {
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        
        System.out.println("Digite seu número");
        Integer numeroDigitado = leitor.nextInt();
        
        Integer somaTotal = 0;
        while (numeroDigitado != 0) {
            somaTotal += numeroDigitado;
            numeroDigitado = leitor.nextInt();
            System.out.println(numeroDigitado);
       }
        System.out.println("A soma dos números é " + somaTotal);
    }
}
