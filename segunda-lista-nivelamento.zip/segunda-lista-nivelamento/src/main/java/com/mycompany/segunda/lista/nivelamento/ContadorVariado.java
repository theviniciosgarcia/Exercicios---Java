/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.segunda.lista.nivelamento;

import java.util.Scanner;

/**
 *
 * @author vgfagundes
 */
public class ContadorVariado {
    public static void main(String[] args) {
        Double soma = 0.15;
        
        for (double i = 0.15; i < 5; i += 0.15) {
            soma *= i;
            System.out.println(String.format("%.2f", i));
        }
    }
}
