/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.segunda.lista.nivelamento;

import java.util.Scanner;

/**
 *
 * @author vgfagundes
 */
public class Votacao {
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        
        System.out.println("Digite o valor: ");
        Integer valorPizza = leitor.nextInt();
        Integer mussarela = 0;
        Integer calabresa = 0;
        Integer quatroQueijos = 0;
        
        String mussarelaFavorita = "mussarela";
        String calabresaFavorita =  "calabresa";
        String quatroQueijosFavorita = "quatroQueijos";
        
        for (int i = 0; i < 10; i++) {
            
            switch(valorPizza) {
            case 5:
              mussarela++;
              break;
            case 25:
                calabresa++;
                break;
            case 50:
               quatroQueijos++;
               break;
            }
            valorPizza = leitor.nextInt(); 
               
        }
        System.out.println("Quantidade de votos:" + mussarela);
        System.out.println("Quantidade de votos:" + calabresa);
        System.out.println("Quantidade de votos:" + quatroQueijos);
        
        if (mussarela > calabresa && mussarela > quatroQueijos) {
        System.out.println("Sabor Favorito: " + mussarelaFavorita);
        }
        
        else if (calabresa > mussarela && calabresa > quatroQueijos) {
        System.out.println("Sabor Favorito: " + calabresaFavorita);
        }
          
        else {
        System.out.println("Sabor Favorito: " + quatroQueijosFavorita);
        }
 }
}
