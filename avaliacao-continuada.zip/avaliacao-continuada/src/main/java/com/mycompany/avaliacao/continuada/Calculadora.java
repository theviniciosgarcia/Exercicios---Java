/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.avaliacao.continuada;

import java.util.Scanner;

/**
 *
 * @author vgfagundes
 */
public class Calculadora {

    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        
        Integer opcoes;
        Integer numeroInteiro;
        
        Double numeroEscolhidoPotencia = 0.0;
        Integer numeroRestoDeDivisao = 0;

        do {
            
            System.out.println("\n1 - Soma\n"
                    + "2 - Multiplicação\n"
                    + "3 - Divisão\n"
                    + "4 - Subtração\n"
                    + "5 - Potência\n"
                    + "6 - Resto de Divisão\n"
                    + "0 – Sair\n");
            
            System.out.println("Escolha uma opção de 0 a 6");
            opcoes = leitor.nextInt();
            
             if (opcoes < 0 || opcoes > 6) {
             System.out.println("Opção inválida, tente novamente");
            }

            switch (opcoes) {
                case 1:
                    System.out.println("Digite um número inteiro:");
                    numeroInteiro = leitor.nextInt();
                    
                    for (int i = 1; i <= 10; i++) {
                        System.out.println(String.format("%d + %d = %d", numeroInteiro, i, numeroInteiro + i));
                    }
                    break;
                case 2:
                    System.out.println("Digite um número inteiro");
                    numeroInteiro = leitor.nextInt();
                    
                    for (int i = 1; i <= 10; i++) {
                        System.out.println(String.format("%d * %d = %d", numeroInteiro, i, numeroInteiro * i));
                    }
                    break;
                case 3:
                    System.out.println("Digite um número inteiro");
                    numeroInteiro = leitor.nextInt();
                    
                    for (int i = 1; i <= 10; i++) {
                        System.out.println(String.format("%d / %d = %d", numeroInteiro, i, numeroInteiro / i));
                    }
                    break;
                case 4:
                    System.out.println("Digite um número inteiro");
                    numeroInteiro = leitor.nextInt();
                    
                    for (int i = 1; i <= 10; i++) {
                        System.out.println(String.format("%d - %d = %d", numeroInteiro, i, numeroInteiro - i));
                    }
                    break;
                case 5:
                    System.out.println("Digite um número inteiro");
                    Double potencia = 1.0;
                    numeroEscolhidoPotencia = leitor.nextDouble();
                    
                    for (double i = 1; i <= 10; i++) {
                        potencia *= numeroEscolhidoPotencia;
                        System.out.println(String.format("%.1f ^ %.1f = %.1f", numeroEscolhidoPotencia, i, potencia));
                    }
                    break;
                case 6: 
                    System.out.println("Digite um número inteiro");
                    numeroInteiro = leitor.nextInt();
                    
                    for (int i = 1; i <= 10; i++) {
                        numeroRestoDeDivisao = numeroInteiro % i;
                        System.out.println(String.format("%d resto da divisão por: %d = %d", numeroInteiro, i, numeroRestoDeDivisao));
                    }
                    break; 
                default:
                    if(opcoes == 0)
                    System.out.println("Até Logo!!");
            }

        } while (opcoes != 0);
    }
}
