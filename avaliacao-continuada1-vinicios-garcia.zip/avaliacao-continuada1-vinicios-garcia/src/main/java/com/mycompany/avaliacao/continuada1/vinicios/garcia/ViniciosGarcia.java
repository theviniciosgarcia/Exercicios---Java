/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.avaliacao.continuada1.vinicios.garcia;

import java.util.Scanner;

/**
 *
 * @author vgfagundes
 */
public class ViniciosGarcia {

    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);

        Integer opcoes;
        Double valorDepositado;
        Double valorSaque;
        Double saldoTotal = 0.0;

        do {
            System.out.println("\nSP Tech Investimentos\n"
                    + "--------------------------\n"
                    + "Olá, O que deseja fazer?:\n"
                    + "--------------------------\n"
                    + "1 - Depositar\n"
                    + "2 - Sacar\n"
                    + "3 - Simular Rendimentos\n"
                    + "0 - Sair\n"
                    + "--------------------------");
            opcoes = leitor.nextInt();

            switch (opcoes) {
                case 1:
                    System.out.println("Digite o valor do depósito:");
                    valorDepositado = leitor.nextDouble();

                    if (valorDepositado <= 0) {
                        System.out.println("Deposito Invalido");
                    } else {
                        saldoTotal += valorDepositado;
                        System.out.println(String.format("Deposito Realizado - Saldo Atual: %.2f", +saldoTotal));
                    }
                    break;

                case 2:
                    System.out.println("Digite o valor do saque:");
                    valorSaque = leitor.nextDouble();

                    if (valorSaque >= saldoTotal && valorSaque == 0) {
                        System.out.println("Saque Invalido");
                    } else {
                        saldoTotal -= valorSaque;
                        System.out.println(String.format("Saque Realizado - Saldo Atual: %.2f", +saldoTotal));
                    }
                    break;
                case 3:
                    if (saldoTotal == 0) {
                        System.out.println("Saldo Zerado, opção inválida.");
                    } else {
                        Double rendimento = saldoTotal * 0.1;
                        Double porcentagem = rendimento + saldoTotal;
                        System.out.println("Saldo Atual: \n" + saldoTotal);

                        int i = 1;
                        while (i != 13) {
                            System.out.println(String.format("-------------------\n"
                                    + "Mês: %d" + " Saldo: %.2f \n"
                                    + "-------------------\n", i, saldoTotal));
                            saldoTotal += (saldoTotal * 0.1);
                            i++;
                        }
                    }
                    break;

                default:
                    if (opcoes == 0) {
                        System.out.println("Até Logo!!");
                    } else {
                        System.out.println("Opcão Invalida");
                    }
            }
        } while (opcoes != 0);
    }
}
