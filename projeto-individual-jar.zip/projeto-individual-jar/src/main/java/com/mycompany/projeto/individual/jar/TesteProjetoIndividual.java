/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projeto.individual.jar;

import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

/**
 *
 * @author vgfagundes
 */
public class TesteProjetoIndividual {

    public static void main(String[] args) {
        ProjetoIndividual pi = new ProjetoIndividual();
        Scanner leitor = new Scanner(System.in);

        Integer opcoes;
        Integer sobre;

        Integer numeroFrequenciaAssistidas;
        Integer numeroFrequenciaEstadio;
        Integer numeroQtdImpacto;

        Integer numeroFavorito;
        Integer numeroDaCamisa = ThreadLocalRandom.current().nextInt(1, 50);

        String nomeDoGoleiro;
        String nomeDoAtacante;
        String iniciar;

        Boolean respostaCerta = false;

        do {

            System.out.println("--------------------------------------\n"
                    + "Seja bem vindo ao programa "
                    + "Sport Club Corinthians Paulista\n\n"
                    + "1 - Quiz - Tipo de torcedor voce é?\n"
                    + "2 - Quiz - Qual é o nome do jogador?\n"
                    + "3 - Game - Qual seria sua numeração"
                    + " se fosse jogador do Corinthians?\n"
                    + "4 - Sobre o Clube!!\n"
                    + "0 - Sair\n"
                    + "------------------------------------------");

            System.out.println("Escolha uma opção de 0 a 4");
            opcoes = leitor.nextInt();

            if (opcoes < 0 || opcoes > 4) {
                System.out.println("Opção inválida, tente novamente\n");
            }

            switch (opcoes) {
                case 1:
                    System.out.println("De 0 a 10, O Quanto você assiste futebol?");
                    numeroFrequenciaAssistidas = leitor.nextInt();

                    System.out.println("De 0 a 10, O Quanto você frequenta estadio de futebol?");
                    numeroFrequenciaEstadio = leitor.nextInt();

                    System.out.println("De 0 a 10, O Quanto futebol impacta na sua vida?");
                    numeroQtdImpacto = leitor.nextInt();

                    Integer numeroInteiro = pi.qtdPts(numeroFrequenciaAssistidas, numeroFrequenciaEstadio, numeroQtdImpacto);
                    System.out.println(String.format("\nResultado: %d\n", numeroInteiro));

                    break;

                case 2:
                    System.out.println("Qual é o nome do goleiro titular do Corinthians?");
                    nomeDoGoleiro = leitor.nextLine();

                    while (!respostaCerta) {
                        nomeDoGoleiro = leitor.nextLine();
                        if (!nomeDoGoleiro.equals("Cássio")
                                && !nomeDoGoleiro.equals("cássio")
                                && !nomeDoGoleiro.equals("CÁSSIO")) {
                            System.out.println("Resposta Incorreta! Tente Novamente!");
                        } else {
                            System.out.println(String.format("\nResposta Correta!! %s\n", nomeDoGoleiro));
                            break;
                        }
                    }

                    System.out.println("\nQual é o nome do atacante número 10 do Corinthians?\n");

                    while (!respostaCerta) {
                        nomeDoAtacante = leitor.nextLine();
                        if (!nomeDoAtacante.equals("Róger guedes")
                                && !nomeDoAtacante.equals("róger guedes")
                                && !nomeDoAtacante.equals("RÓGER GUEDES")) {
                            System.out.println("\nResposta Incorreta! Tente Novamente!\n");
                        } else {
                            System.out.println(String.format("\nResposta Correta!! %s\n"
                                    + "Parabéns você venceu o quiz!!", nomeDoAtacante));
                            break;
                        }
                    }
                    break;

                case 3:
                    System.out.println("\nSeja Bem Vindo ao jogo adivinhe seu número "
                            + "se fosse um jogador do Corinthians, \nPara começar basta escrever o seu número favorito "
                            + "e teste sua sorte "
                            + "que você sabera o seu número."
                            + "\nObs: o númeração é baseada na quantidade de jogdores em campo,\n"
                            + "onde a númeração vai de 1 a 11.\n");

                    System.out.println("Escolha seu número favorito");
                    numeroFavorito = leitor.nextInt();
                    numeroDaCamisa = ThreadLocalRandom.current().nextInt(1, 11);

                    int i = 1;
                    while (numeroDaCamisa != numeroFavorito) {
                        numeroDaCamisa = ThreadLocalRandom.current().nextInt(1, 11);
                        System.out.println(numeroDaCamisa);

                        System.out.println(String.format("Temporada: %d Sua camisa nessa temporada é a %d\n", i, numeroDaCamisa));
                        i++;

                        if (i > 18) {
                            System.out.println("Você jogou " + i + " temporadas em toda sua carreira!");
                            System.out.println("Infelizmente você se aposentou sem jogar com sua camisa favorita");
                            break;

                        } else if (numeroDaCamisa == numeroFavorito) {
                            System.out.println("Parabéns você é o nosso camisa " + numeroFavorito);
                            System.out.println("Você demorou " + i + " temporadas para jogar com sua camisa favorita");
                        }
                    }
                    break;

                case 4:

                    do {

                        System.out.println("O que você deseja ver:");

                        System.out.println("--------------------------------------\n"
                                + "1 - Origem do SCCP\n"
                                + "2 - Clube hoje em dia\n"
                                + "3 - O que é ser Corinthians?\n"
                                + "0 - Sair\n"
                                + "------------------------------------------");
                        sobre = leitor.nextInt();

                        if (sobre < 0 || sobre > 3) {
                            System.out.println("Opção Invalida, Tente novamente\n");
                        } else {

                            pi.sobreClube(sobre);

                        }
                    } while (sobre != 0);

                default:
                    if (opcoes == 0) {
                        System.out.println("Até Breve!!!");
                    }
            }

        } while (opcoes != 0);
    }

}
