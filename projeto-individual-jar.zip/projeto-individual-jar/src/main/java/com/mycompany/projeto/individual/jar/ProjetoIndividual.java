/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projeto.individual.jar;

/**
 *
 * @author vgfagundes
 */
public class ProjetoIndividual {

    Integer qtdPts(Integer frequenciaAssistida, Integer frequenciaEstadio, Integer impacto) {
        if (frequenciaAssistida < 0 || frequenciaAssistida > 10
                || frequenciaEstadio < 0 || frequenciaEstadio > 10
                || impacto < 0 || impacto > 10) {
            System.out.println("\nOpções inválidas, tente novamente");
        } else {
            Integer numeroInteiro = frequenciaAssistida + frequenciaEstadio + impacto;

            if (numeroInteiro > 25) {
                System.out.println("\nParabéns! Você é um torcedor louco!!");
                return numeroInteiro;
            } else if (numeroInteiro > 15 && numeroInteiro < 25) {
                System.out.println("\nParabéns! Você é um torcedor fanatico");
                return numeroInteiro;
            } else if (numeroInteiro > 0 && numeroInteiro <= 15) {
                System.out.println("\nParabéns! Você é um torcedor comum");
                return numeroInteiro;
            } else {
                System.out.println("Você não acompanha futebol?\n"
                        + "Recomendo que assista!! e se quiser\n"
                        + "indico um ótimo time para torcer!!\n"
                        + "Saiba mais em" + " Sobre o clube" + " no nosso menu!!");
                return numeroInteiro;
            }
        }
        return null;
    }

    void sobreClube(Integer sobre) {
        switch (sobre) {
            case 1:
                System.out.println("1910 A fundação. Às 20h30 do dia 1º de setembro, à luz de um lampião, na esquina das ruas José Paulino e Cônego Martins,\n"
                        + "no bairro do Bom Retiro, o grupo de operários formado por Anselmo Corrêa, Antônio Pereira, Carlos Silva,\n"
                        + "Joaquim Ambrósio e Raphael Perrone\n"
                        + "fundaram o Sport Club Corinthians Paulista.\n");
                break;

            case 2:
                System.out.println("| Títulos |\n"
                        + "| taça |\n\n"
                        + "| Mundial |\n\n"
                        + "| 2 títulos |\n"
                        + "| 2000 |\n"
                        + "| 2012 |\n\n"
                        + "| taça |\n\n"
                        + "| Copa Libertadores da América |\n\n"
                        + "| 2012 |\n\n"
                        + "| 1 título |\n"
                        + "| taça |\n\n"
                        + "| recopa sul-americana |\n\n"
                        + "| 2012 |\n\n"
                        + "| 1 titulo |\n\n"
                        + "| taça |\n\n"
                        + "| Campeonato Brasileiro |\n\n"
                        + "| 7 títulos |\n"
                        + "| 1990, 1998, 1999, 2005, 2011, 2015 e 2017 |\n\n"
                        + "| taça |\n\n"
                        + "| Copa do Brasil |\n\n"
                        + "| 3 títulos |\n"
                        + "| 1995, 2002 e 2009 |\n\n"
                        + "| taça |\n\n"
                        + "| Campeonato Brasileiro - Série B |\n\n"
                        + "| 1 título |\n"
                        + "| 2008 |\n\n"
                        + "| taça |\n\n"
                        + "| Torneio Rio-São Paulo |\n\n"
                        + "| 5 títulos |\n"
                        + "| 1950, 1953, 1954, 1966 e 2002 |\n\n"
                        + "| taça |\n\n"
                        + "| Supercopa da Copa do Brasil |\n\n"
                        + "| 1 título |\n"
                        + "| 1991 |\n\n"
                        + "| taça |\n\n"
                        + "| Campeonato Paulista |\n\n"
                        + "| 30 títulos |\n"
                        + "| 1914, 1916, 1922, 1923, 1924, 1928, 1929 |\n"
                        + "| 1930, 1937, 1938, 1939, 1941, 1951, 1952 |\n"
                        + "| 1954, 1977, 1979, 1982, 1983, 1988, 1995 |\n"
                        + "| 1997, 1999, 2001, 2003, 2009, 2013, 2017 |\n"
                        + "| 2018 e 2019");
                break;
            case 3:
                System.out.println("Ser Corintiano não é apenas torcer para um time de futebol.\n"
                        + "É um estado de espírito.\n"
                        + "É um jeito corajoso, valente e apaixonado de viver a vida!");
                break;
                
            default:
                if (sobre == 0) {
                System.out.println("Voltando ao menu...");
                }      
        }
    }
}
